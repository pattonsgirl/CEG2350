///	@mainpage Documentation Main Page
///
/// _Welcome to the nSnake code documentation!_ <br /><br />
///
/// This page is for people who want to understand how nSnake was made
/// (it's source code). <br />
/// If you're not after this, check out the links below:
///
/// * [nSnake homepage](http://nsnake.alexdantas.net)
/// * [nSnake on GitHub](https://github.com/alexdantas/nsnake)
///
/// \tableofcontents
///
///  ## Introduction
///
///  ...<b>I really should put something here</b>...
///
///  ## Contact
///
///  Any questions, please email me at <eu@alexdantas.net>

